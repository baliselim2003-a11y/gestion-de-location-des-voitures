# 🚗 ApexDrive - Car Rental Web Application (IntelliJ IDEA Guide)

A full-stack enterprise car rental platform built with standard layered architecture (**Spring Boot / Java 17 / Jakarta EE / JPA / MySQL & H2**) and a modern frontend website (**HTML5 / CSS3 / JavaScript**).

---

## 🚀 Running with IntelliJ IDEA 2026.2.3

### Step 1: Open the Project
1. Launch **IntelliJ IDEA 2026.2.3**.
2. Click **Open** (or **File** $\rightarrow$ **Open...**).
3. Browse to and select the folder:
   ```
   c:\car rent
   ```
4. Click **OK**. If prompted, select **Trust Project** and open as **Maven Project**.

### Step 2: Ensure Java 17 SDK is Selected
1. Go to **File** $\rightarrow$ **Project Structure...** (Shortcut: `Ctrl + Alt + Shift + S`).
2. Under **Project Settings** $\rightarrow$ **Project**:
   - **SDK**: Select **17** (e.g. `openjdk-17`). If not configured, click **Add SDK** $\rightarrow$ **Download JDK...** or point to your installed Java 17 path.
   - **Language level**: Select **17**.
3. Click **Apply** and **OK**.

### Step 3: Run the Application
You have two easy ways:

- **Method A (Top Toolbar)**:
  Look at the top-right toolbar next to the green **Play (▶)** button.
  Select **CarRentalApplication** from the dropdown and click **Run (▶)** (or press `Shift + F10`).

- **Method B (Direct Class Run)**:
  In the Project tool window (left panel), navigate to:
  `src` $\rightarrow$ `main` $\rightarrow$ `java` $\rightarrow$ `com.carrental` $\rightarrow$ `CarRentalApplication.java`
  Right-click `CarRentalApplication.java` and click **Run 'CarRentalApplication.main()'**.

### Step 4: Open in Your Browser
Once the console prints:
```
Started CarRentalApplication in ... seconds
```
Open your browser and navigate to:
👉 **[http://localhost:8080/](http://localhost:8080/)**

---

## 🗄️ H2 Database Web Console
- URL: **[http://localhost:8080/h2-console](http://localhost:8080/h2-console)**
- JDBC URL: `jdbc:h2:mem:carrentaldb`
- User Name: `sa`
- Password: *(leave blank)*

---

## 🔑 Demo Customer Logins
| Role | Email | Password |
|---|---|---|
| **Customer** | `sarah.connor@example.com` | `password123` |
| **Administrator** | `admin@carrent.com` | `admin123` |
