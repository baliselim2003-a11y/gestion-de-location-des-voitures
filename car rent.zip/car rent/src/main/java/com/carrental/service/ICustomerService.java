package com.carrental.service;

import com.carrental.model.Customer;
import java.util.List;

public interface ICustomerService {

    // 1. Add (Create)
    Customer add(Customer customer);

    // 2. Modify (Update)
    Customer modify(Customer customer);
    Customer modify(Long id, Customer customer);

    // 3. Show (Read)
    List<Customer> show();
    Customer show(Long id);

    // 4. Delete
    void delete(Long id);

    // Specific Domain Methods
    Customer findByEmail(String email);
    Customer authenticate(String email, String password);
}
