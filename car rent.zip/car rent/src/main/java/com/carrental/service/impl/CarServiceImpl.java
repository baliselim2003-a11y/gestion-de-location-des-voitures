package com.carrental.service.impl;

import com.carrental.model.Car;
import com.carrental.repository.CarRepository;
import com.carrental.service.ICarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class CarServiceImpl implements ICarService {

    private final CarRepository carRepository;

    @Autowired
    public CarServiceImpl(CarRepository carRepository) {
        this.carRepository = carRepository;
    }

    @Override
    public Car add(Car car) {
        if (car == null) {
            throw new IllegalArgumentException("Car cannot be null");
        }
        if (car.getLicensePlate() != null && carRepository.existsByLicensePlate(car.getLicensePlate())) {
            throw new IllegalArgumentException("License plate " + car.getLicensePlate() + " already exists.");
        }
        return carRepository.save(car);
    }

    @Override
    public Car modify(Car car) {
        if (car == null || car.getId() == null) {
            throw new IllegalArgumentException("Car and car ID cannot be null for modify");
        }
        return carRepository.save(car);
    }

    @Override
    public Car modify(Long id, Car carDetails) {
        Car existing = show(id);
        existing.setBrand(carDetails.getBrand());
        existing.setModel(carDetails.getModel());
        existing.setCategory(carDetails.getCategory());
        existing.setYear(carDetails.getYear());
        existing.setLicensePlate(carDetails.getLicensePlate());
        existing.setPricePerDay(carDetails.getPricePerDay());
        existing.setFuelType(carDetails.getFuelType());
        existing.setTransmission(carDetails.getTransmission());
        existing.setSeats(carDetails.getSeats());
        if (carDetails.getImageUrl() != null) {
            existing.setImageUrl(carDetails.getImageUrl());
        }
        if (carDetails.getAvailable() != null) {
            existing.setAvailable(carDetails.getAvailable());
        }
        existing.setDescription(carDetails.getDescription());
        return carRepository.save(existing);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Car> show() {
        return carRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Car show(Long id) {
        return carRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Car not found with id: " + id));
    }

    @Override
    public void delete(Long id) {
        if (!carRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete: Car not found with id: " + id);
        }
        carRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Car> showAvailableCars() {
        return carRepository.findByAvailableTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Car> showByCategory(String category) {
        return carRepository.findByCategoryIgnoreCase(category);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Car> searchCars(String brand, String category, BigDecimal maxPrice) {
        return carRepository.findAll().stream()
                .filter(car -> brand == null || brand.isBlank() || car.getBrand().toLowerCase().contains(brand.toLowerCase()) || car.getModel().toLowerCase().contains(brand.toLowerCase()))
                .filter(car -> category == null || category.isBlank() || category.equalsIgnoreCase("ALL") || car.getCategory().equalsIgnoreCase(category))
                .filter(car -> maxPrice == null || car.getPricePerDay().compareTo(maxPrice) <= 0)
                .toList();
    }
}
