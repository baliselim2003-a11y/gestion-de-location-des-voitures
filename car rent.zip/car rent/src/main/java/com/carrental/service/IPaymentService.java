package com.carrental.service;

import com.carrental.model.Payment;
import java.util.List;

public interface IPaymentService {

    // 1. Add (Create)
    Payment add(Payment payment);

    // 2. Modify (Update)
    Payment modify(Payment payment);
    Payment modify(Long id, Payment payment);

    // 3. Show (Read)
    List<Payment> show();
    Payment show(Long id);

    // 4. Delete
    void delete(Long id);

    // Specific Domain Methods
    Payment showByRentalId(Long rentalId);
}
