package com.carrental.service;

import com.carrental.model.Car;
import java.math.BigDecimal;
import java.util.List;

public interface ICarService {

    // 1. Add (Create)
    Car add(Car car);

    // 2. Modify (Update)
    Car modify(Car car);
    Car modify(Long id, Car car);

    // 3. Show (Read)
    List<Car> show();
    Car show(Long id);

    // 4. Delete
    void delete(Long id);

    // Specific Domain Methods
    List<Car> showAvailableCars();
    List<Car> showByCategory(String category);
    List<Car> searchCars(String brand, String category, BigDecimal maxPrice);
}
