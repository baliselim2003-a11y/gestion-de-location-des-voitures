package com.carrental.service.impl;

import com.carrental.model.Car;
import com.carrental.model.Customer;
import com.carrental.model.Rental;
import com.carrental.repository.CarRepository;
import com.carrental.repository.CustomerRepository;
import com.carrental.repository.RentalRepository;
import com.carrental.service.IRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class RentalServiceImpl implements IRentalService {

    private final RentalRepository rentalRepository;
    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;

    @Autowired
    public RentalServiceImpl(RentalRepository rentalRepository, CarRepository carRepository, CustomerRepository customerRepository) {
        this.rentalRepository = rentalRepository;
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public Rental add(Rental rental) {
        if (rental == null) {
            throw new IllegalArgumentException("Rental cannot be null");
        }
        if (rental.getCustomer() == null || rental.getCustomer().getId() == null) {
            throw new IllegalArgumentException("Customer must be specified for rental");
        }
        if (rental.getCar() == null || rental.getCar().getId() == null) {
            throw new IllegalArgumentException("Car must be specified for rental");
        }

        Customer customer = customerRepository.findById(rental.getCustomer().getId())
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + rental.getCustomer().getId()));
        Car car = carRepository.findById(rental.getCar().getId())
                .orElseThrow(() -> new RuntimeException("Car not found with id: " + rental.getCar().getId()));

        if (!car.getAvailable()) {
            throw new IllegalStateException("Selected car " + car.getBrand() + " " + car.getModel() + " is currently unavailable for rent.");
        }

        rental.setCustomer(customer);
        rental.setCar(car);

        if (rental.getTotalPrice() == null || rental.getTotalPrice().compareTo(BigDecimal.ZERO) <= 0) {
            long days = ChronoUnit.DAYS.between(rental.getStartDate(), rental.getEndDate());
            if (days <= 0) days = 1;
            rental.setTotalPrice(car.getPricePerDay().multiply(BigDecimal.valueOf(days)));
        }

        if (rental.getStatus() == null) {
            rental.setStatus("CONFIRMED");
        }

        return rentalRepository.save(rental);
    }

    @Override
    public Rental modify(Rental rental) {
        if (rental == null || rental.getId() == null) {
            throw new IllegalArgumentException("Rental and ID cannot be null for modify");
        }
        return rentalRepository.save(rental);
    }

    @Override
    public Rental modify(Long id, Rental rentalDetails) {
        Rental existing = show(id);
        existing.setStartDate(rentalDetails.getStartDate());
        existing.setEndDate(rentalDetails.getEndDate());
        existing.setPickupLocation(rentalDetails.getPickupLocation());
        existing.setReturnLocation(rentalDetails.getReturnLocation());
        if (rentalDetails.getTotalPrice() != null) {
            existing.setTotalPrice(rentalDetails.getTotalPrice());
        }
        if (rentalDetails.getStatus() != null) {
            existing.setStatus(rentalDetails.getStatus());
        }
        return rentalRepository.save(existing);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Rental> show() {
        return rentalRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Rental show(Long id) {
        return rentalRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Rental not found with id: " + id));
    }

    @Override
    public void delete(Long id) {
        if (!rentalRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete: Rental not found with id: " + id);
        }
        rentalRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Rental> showByCustomerId(Long customerId) {
        return rentalRepository.findByCustomerId(customerId);
    }

    @Override
    public Rental cancelRental(Long id) {
        Rental rental = show(id);
        rental.setStatus("CANCELLED");
        return rentalRepository.save(rental);
    }

    @Override
    public Rental confirmRental(Long id) {
        Rental rental = show(id);
        rental.setStatus("CONFIRMED");
        return rentalRepository.save(rental);
    }
}
