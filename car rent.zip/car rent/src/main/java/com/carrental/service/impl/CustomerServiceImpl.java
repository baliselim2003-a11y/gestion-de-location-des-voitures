package com.carrental.service.impl;

import com.carrental.model.Customer;
import com.carrental.repository.CustomerRepository;
import com.carrental.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public Customer add(Customer customer) {
        if (customer == null) {
            throw new IllegalArgumentException("Customer cannot be null");
        }
        if (customerRepository.existsByEmail(customer.getEmail())) {
            throw new IllegalArgumentException("A customer with email " + customer.getEmail() + " already exists.");
        }
        if (customer.getDrivingLicense() != null && customerRepository.existsByDrivingLicense(customer.getDrivingLicense())) {
            throw new IllegalArgumentException("Driving license " + customer.getDrivingLicense() + " is already registered.");
        }
        return customerRepository.save(customer);
    }

    @Override
    public Customer modify(Customer customer) {
        if (customer == null || customer.getId() == null) {
            throw new IllegalArgumentException("Customer and customer ID cannot be null for modify");
        }
        return customerRepository.save(customer);
    }

    @Override
    public Customer modify(Long id, Customer customerDetails) {
        Customer existing = show(id);
        existing.setFirstName(customerDetails.getFirstName());
        existing.setLastName(customerDetails.getLastName());
        existing.setPhone(customerDetails.getPhone());
        existing.setAddress(customerDetails.getAddress());
        if (customerDetails.getDrivingLicense() != null) {
            existing.setDrivingLicense(customerDetails.getDrivingLicense());
        }
        if (customerDetails.getPassword() != null && !customerDetails.getPassword().isBlank()) {
            existing.setPassword(customerDetails.getPassword());
        }
        return customerRepository.save(existing);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Customer> show() {
        return customerRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Customer show(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
    }

    @Override
    public void delete(Long id) {
        if (!customerRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete: Customer not found with id: " + id);
        }
        customerRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Customer findByEmail(String email) {
        return customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found with email: " + email));
    }

    @Override
    @Transactional(readOnly = true)
    public Customer authenticate(String email, String password) {
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));
        if (!customer.getPassword().equals(password)) {
            throw new RuntimeException("Invalid email or password");
        }
        return customer;
    }
}
