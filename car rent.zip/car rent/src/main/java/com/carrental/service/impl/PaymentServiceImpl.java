package com.carrental.service.impl;

import com.carrental.model.Payment;
import com.carrental.model.Rental;
import com.carrental.repository.PaymentRepository;
import com.carrental.repository.RentalRepository;
import com.carrental.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PaymentServiceImpl implements IPaymentService {

    private final PaymentRepository paymentRepository;
    private final RentalRepository rentalRepository;

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository, RentalRepository rentalRepository) {
        this.paymentRepository = paymentRepository;
        this.rentalRepository = rentalRepository;
    }

    @Override
    public Payment add(Payment payment) {
        if (payment == null) {
            throw new IllegalArgumentException("Payment cannot be null");
        }
        if (payment.getRental() == null || payment.getRental().getId() == null) {
            throw new IllegalArgumentException("Payment must reference a valid rental ID");
        }
        Rental rental = rentalRepository.findById(payment.getRental().getId())
                .orElseThrow(() -> new RuntimeException("Rental not found with id: " + payment.getRental().getId()));

        payment.setRental(rental);
        if (payment.getAmount() == null) {
            payment.setAmount(rental.getTotalPrice());
        }
        if (payment.getPaymentStatus() == null) {
            payment.setPaymentStatus("COMPLETED");
        }
        return paymentRepository.save(payment);
    }

    @Override
    public Payment modify(Payment payment) {
        if (payment == null || payment.getId() == null) {
            throw new IllegalArgumentException("Payment and ID cannot be null for modify");
        }
        return paymentRepository.save(payment);
    }

    @Override
    public Payment modify(Long id, Payment paymentDetails) {
        Payment existing = show(id);
        if (paymentDetails.getAmount() != null) {
            existing.setAmount(paymentDetails.getAmount());
        }
        if (paymentDetails.getPaymentMethod() != null) {
            existing.setPaymentMethod(paymentDetails.getPaymentMethod());
        }
        if (paymentDetails.getPaymentStatus() != null) {
            existing.setPaymentStatus(paymentDetails.getPaymentStatus());
        }
        return paymentRepository.save(existing);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Payment> show() {
        return paymentRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Payment show(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with id: " + id));
    }

    @Override
    public void delete(Long id) {
        if (!paymentRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete: Payment not found with id: " + id);
        }
        paymentRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Payment showByRentalId(Long rentalId) {
        return paymentRepository.findByRentalId(rentalId)
                .orElseThrow(() -> new RuntimeException("Payment not found for rental id: " + rentalId));
    }
}
