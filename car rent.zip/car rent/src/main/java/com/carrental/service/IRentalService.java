package com.carrental.service;

import com.carrental.model.Rental;
import java.util.List;

public interface IRentalService {

    // 1. Add (Create)
    Rental add(Rental rental);

    // 2. Modify (Update)
    Rental modify(Rental rental);
    Rental modify(Long id, Rental rental);

    // 3. Show (Read)
    List<Rental> show();
    Rental show(Long id);

    // 4. Delete
    void delete(Long id);

    // Specific Domain Methods
    List<Rental> showByCustomerId(Long customerId);
    Rental cancelRental(Long id);
    Rental confirmRental(Long id);
}
