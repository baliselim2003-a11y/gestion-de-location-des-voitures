package com.carrental.controller;

import com.carrental.model.Customer;
import com.carrental.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final ICustomerService customerService;

    @Autowired
    public AuthController(ICustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        if (email == null || password == null) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Email and password are required.");
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }

        try {
            Customer customer = customerService.authenticate(email, password);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login successful!");
            response.put("customer", sanitizeCustomer(customer));
            return ResponseEntity.ok(response);
        } catch (RuntimeException ex) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Invalid credentials. Please check your email and password.");
            return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Customer customer) {
        try {
            Customer saved = customerService.add(customer);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Registration successful! Welcome to CarRent.");
            response.put("customer", sanitizeCustomer(saved));
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IllegalArgumentException ex) {
            Map<String, String> error = new HashMap<>();
            error.put("error", ex.getMessage());
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Registration failed: " + ex.getMessage());
            return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/google-verify")
    public ResponseEntity<?> googleVerify(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        if (email == null || email.trim().isEmpty()) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Email is required.");
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }
        email = email.trim().toLowerCase();
        Customer customer = customerService.findByEmail(email);
        if (customer == null) {
            String namePart = email.split("@")[0].replaceAll("[^a-zA-Z]", " ").trim();
            String[] parts = namePart.split("\\s+");
            String firstName = parts.length > 0 && !parts[0].isEmpty() ?
                    Character.toUpperCase(parts[0].charAt(0)) + parts[0].substring(1) : "Google";
            String lastName = parts.length > 1 && !parts[1].isEmpty() ?
                    Character.toUpperCase(parts[1].charAt(0)) + parts[1].substring(1) : "User";
            Customer newCustomer = new Customer();
            newCustomer.setFirstName(firstName);
            newCustomer.setLastName(lastName);
            newCustomer.setEmail(email);
            newCustomer.setPassword("GOOGLE_OAUTH_" + System.currentTimeMillis());
            newCustomer.setPhone("+216 20 000 000");
            newCustomer.setDrivingLicense("TN-G-" + (int)(100000 + Math.random() * 900000));
            newCustomer.setAddress("Tunis, Tunisie");
            newCustomer.setRole("ROLE_CUSTOMER");
            customer = customerService.add(newCustomer);
        }
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Google verification successful!");
        response.put("customer", sanitizeCustomer(customer));
        return ResponseEntity.ok(response);
    }

    private Map<String, Object> sanitizeCustomer(Customer customer) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", customer.getId());
        map.put("firstName", customer.getFirstName());
        map.put("lastName", customer.getLastName());
        map.put("email", customer.getEmail());
        map.put("phone", customer.getPhone());
        map.put("drivingLicense", customer.getDrivingLicense());
        map.put("address", customer.getAddress());
        map.put("role", customer.getRole());
        return map;
    }
}
