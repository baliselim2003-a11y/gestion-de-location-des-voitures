package com.carrental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRentalApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarRentalApplication.class, args);
        System.out.println("=================================================");
        System.out.println(" Car Rental Web Application started successfully! ");
        System.out.println(" URL: http://localhost:8080/                      ");
        System.out.println(" H2 Console: http://localhost:8080/h2-console     ");
        System.out.println("=================================================");
    }
}
