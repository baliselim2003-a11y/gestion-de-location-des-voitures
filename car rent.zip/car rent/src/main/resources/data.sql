-- =====================================================================
-- INITIAL SEED DATA FOR SPRING BOOT / H2 / MYSQL
-- =====================================================================

INSERT INTO customers (id, first_name, last_name, email, password, phone, driving_license, address, role, created_at)
VALUES 
(1, 'Admin', 'User', 'admin@carrent.com', 'admin123', '+1-555-0100', 'DL-ADMIN-001', '100 Luxury Blvd, Beverly Hills, CA', 'ROLE_ADMIN', CURRENT_TIMESTAMP),
(2, 'Sarah', 'Connor', 'sarah.connor@example.com', 'password123', '+1-555-0123', 'DL-CA-987654', '742 Evergreen Terrace, Los Angeles, CA', 'ROLE_CUSTOMER', CURRENT_TIMESTAMP),
(3, 'Michael', 'Scott', 'michael.scott@example.com', 'password123', '+1-555-0456', 'DL-PA-123456', '1725 Slough Avenue, Scranton, PA', 'ROLE_CUSTOMER', CURRENT_TIMESTAMP);

INSERT INTO cars (id, brand, model, category, year, license_plate, price_per_day, fuel_type, transmission, seats, image_url, available, description)
VALUES 
(1, 'Mercedes-Benz', 'S-Class S580', 'LUXURY', 2024, 'MERC-580-LUX', 220.00, 'Hybrid', 'Automatic', 5, 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80', TRUE, 'The pinnacle of luxury engineering, featuring massage seats, twin-turbo V8, and executive rear seating.'),
(2, 'BMW', 'M4 Competition Coupe', 'SPORTS', 2023, 'BMW-M4-FAST', 185.00, 'Petrol', 'Automatic', 4, 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80', TRUE, 'Track-ready performance with 503 horsepower, carbon fiber accents, and M-xDrive all-wheel drive.'),
(3, 'Porsche', 'Taycan 4S', 'ELECTRIC', 2024, 'POR-TAY-ELEC', 210.00, 'Electric', 'Automatic', 4, 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80', TRUE, 'Pure sports car electric performance with 800V architecture and 0-60 mph in 3.8 seconds.'),
(4, 'Range Rover', 'Sport Autobiography', 'SUV', 2024, 'RR-SPORT-SUV', 195.00, 'Petrol', 'Automatic', 5, 'https://images.unsplash.com/photo-1606611013016-969c19ba27bb?auto=format&fit=crop&w=800&q=80', TRUE, 'Commanding presence, peerless off-road and on-road capability, and bespoke leather cabin.'),
(5, 'Tesla', 'Model 3 Performance', 'ELECTRIC', 2023, 'TESLA-M3-P', 95.00, 'Electric', 'Automatic', 5, 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=800&q=80', TRUE, 'Instant torque, cutting-edge autopilot tech, minimalist cabin, and 315-mile battery range.'),
(6, 'Audi', 'RS7 Sportback', 'SPORTS', 2023, 'AUDI-RS7-RED', 190.00, 'Petrol', 'Automatic', 5, 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&w=800&q=80', TRUE, 'Aggressive widebody styling, 591-hp twin-turbo V8, Quattro AWD, and stunning sportback silhouette.'),
(7, 'Mercedes-Benz', 'G63 AMG G-Wagon', 'LUXURY', 2024, 'MERC-G63-V8', 290.00, 'Petrol', 'Automatic', 5, 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&w=800&q=80', TRUE, 'Iconic boxy silhouette, side-exit exhausts, Burmester 3D surround sound, and handcrafted twin-turbo V8.'),
(8, 'Toyota', 'Camry XSE Hybrid', 'SEDAN', 2024, 'TOY-CAM-789', 55.00, 'Hybrid', 'Automatic', 5, 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=800&q=80', TRUE, 'Superb fuel efficiency (52 MPG), smooth ride, panoramic sunroof, and Toyota Safety Sense 3.0.');

INSERT INTO rentals (id, customer_id, car_id, start_date, end_date, total_price, status, pickup_location, return_location, created_at)
VALUES 
(1, 2, 1, '2026-11-10', '2026-11-15', 1100.00, 'CONFIRMED', 'LAX Airport Terminal 3', 'LAX Airport Terminal 3', CURRENT_TIMESTAMP),
(2, 3, 5, '2026-11-12', '2026-11-16', 380.00, 'PENDING', 'Downtown Scranton Office', 'Downtown Scranton Office', CURRENT_TIMESTAMP);

INSERT INTO payments (id, rental_id, amount, payment_date, payment_method, payment_status)
VALUES 
(1, 1, 1100.00, CURRENT_TIMESTAMP, 'CREDIT_CARD', 'COMPLETED');

-- Restart auto-increment sequences past initial seed IDs
ALTER TABLE customers ALTER COLUMN id RESTART WITH 10;
ALTER TABLE cars ALTER COLUMN id RESTART WITH 10;
ALTER TABLE rentals ALTER COLUMN id RESTART WITH 10;
ALTER TABLE payments ALTER COLUMN id RESTART WITH 10;
