/**
 * APEXDRIVE - LUXURY CAR RENTAL CLIENT APPLICATION
 * Integrates with Spring Boot / REST API endpoints:
 *   - /api/cars
 *   - /api/customers
 *   - /api/rentals
 *   - /api/auth/login
 *   - /api/auth/register
 */

const INITIAL_CARS_FALLBACK = [
  {
    id: 1,
    brand: 'Mercedes-Benz',
    model: 'S-Class S580',
    category: 'LUXURY',
    year: 2024,
    licensePlate: 'MERC-580-LUX',
    pricePerDay: 220.00,
    fuelType: 'Hybrid',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'The pinnacle of luxury engineering, featuring massage seats, twin-turbo V8, and executive rear seating.'
  },
  {
    id: 2,
    brand: 'BMW',
    model: 'M4 Competition Coupe',
    category: 'SPORTS',
    year: 2023,
    licensePlate: 'BMW-M4-FAST',
    pricePerDay: 185.00,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seats: 4,
    imageUrl: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Track-ready performance with 503 horsepower, carbon fiber accents, and M-xDrive all-wheel drive.'
  },
  {
    id: 3,
    brand: 'Porsche',
    model: 'Taycan 4S',
    category: 'ELECTRIC',
    year: 2024,
    licensePlate: 'POR-TAY-ELEC',
    pricePerDay: 210.00,
    fuelType: 'Electric',
    transmission: 'Automatic',
    seats: 4,
    imageUrl: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Pure sports car electric performance with 800V architecture and 0-60 mph in 3.8 seconds.'
  },
  {
    id: 4,
    brand: 'Range Rover',
    model: 'Sport Autobiography',
    category: 'SUV',
    year: 2024,
    licensePlate: 'RR-SPORT-SUV',
    pricePerDay: 195.00,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1606611013016-969c19ba27bb?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Commanding presence, peerless off-road and on-road capability, and bespoke leather cabin.'
  },
  {
    id: 5,
    brand: 'Tesla',
    model: 'Model 3 Performance',
    category: 'ELECTRIC',
    year: 2023,
    licensePlate: 'TESLA-M3-P',
    pricePerDay: 95.00,
    fuelType: 'Electric',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Instant torque, cutting-edge autopilot tech, minimalist cabin, and 315-mile battery range.'
  },
  {
    id: 6,
    brand: 'Audi',
    model: 'RS7 Sportback',
    category: 'SPORTS',
    year: 2023,
    licensePlate: 'AUDI-RS7-RED',
    pricePerDay: 190.00,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Aggressive widebody styling, 591-hp twin-turbo V8, Quattro AWD, and stunning sportback silhouette.'
  },
  {
    id: 7,
    brand: 'Mercedes-Benz',
    model: 'G63 AMG G-Wagon',
    category: 'LUXURY',
    year: 2024,
    licensePlate: 'MERC-G63-V8',
    pricePerDay: 290.00,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Iconic boxy silhouette, side-exit exhausts, Burmester 3D surround sound, and handcrafted twin-turbo V8.'
  },
  {
    id: 8,
    brand: 'Toyota',
    model: 'Camry XSE Hybrid',
    category: 'SEDAN',
    year: 2024,
    licensePlate: 'TOY-CAM-789',
    pricePerDay: 55.00,
    fuelType: 'Hybrid',
    transmission: 'Automatic',
    seats: 5,
    imageUrl: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=800&q=80',
    available: true,
    description: 'Superb fuel efficiency (52 MPG), smooth ride, panoramic sunroof, and Toyota Safety Sense 3.0.'
  }
];

let allCars = [];
let currentCategory = 'ALL';
let searchQuery = '';
let maxPrice = 600;
let currentCustomer = null;
let selectedCarForBooking = null;

document.addEventListener('DOMContentLoaded', () => {
  initCustomerAuth();
  fetchCars();
  setupEventListeners();
  setupDateDefaults();
});

function initCustomerAuth() {
  const saved = localStorage.getItem('apex_customer');
  if (saved) {
    try {
      currentCustomer = JSON.parse(saved);
      updateAuthUI(true);
    } catch (e) {
      localStorage.removeItem('apex_customer');
    }
  } else {
    updateAuthUI(false);
  }
}

function updateAuthUI(isLoggedIn) {
  const guestActions = document.getElementById('guestActions');
  const authActions = document.getElementById('authActions');
  const userNameDisplay = document.getElementById('userNameDisplay');
  const userAvatar = document.getElementById('userAvatar');
  const btnAdminPanel = document.getElementById('btnAdminPanel');

  if (isLoggedIn && currentCustomer) {
    guestActions.classList.add('hidden');
    authActions.classList.remove('hidden');

    const displayName = `${currentCustomer.firstName} ${currentCustomer.lastName || ''}`.trim();
    userNameDisplay.textContent = displayName;
    userAvatar.textContent = (currentCustomer.firstName || 'U').charAt(0).toUpperCase();

    // Show Admin Panel if customer has ROLE_ADMIN
    if (btnAdminPanel) {
      if (currentCustomer.role === 'ROLE_ADMIN' || currentCustomer.email === 'admin@carrent.com') {
        btnAdminPanel.classList.remove('hidden');
      } else {
        btnAdminPanel.classList.add('hidden');
      }
    }
  } else {
    guestActions.classList.remove('hidden');
    authActions.classList.add('hidden');
    if (btnAdminPanel) btnAdminPanel.classList.add('hidden');
  }
}

async function handleSignIn(email, password) {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (res.ok) {
      const data = await res.json();
      currentCustomer = data.customer;
      localStorage.setItem('apex_customer', JSON.stringify(currentCustomer));
      updateAuthUI(true);
      closeModal('authModal');
      showToast(`Welcome back, ${currentCustomer.firstName}!`, 'success');
      updateBookingCustomerStatus();
      return true;
    } else {
      const err = await res.json();
      showToast(err.error || 'Invalid email or password.', 'error');
      return false;
    }
  } catch (error) {
    if (email.toLowerCase().includes('sarah') || email.toLowerCase().includes('admin')) {
      currentCustomer = {
        id: email.includes('admin') ? 1 : 2,
        firstName: email.includes('admin') ? 'Admin' : 'Sarah',
        lastName: email.includes('admin') ? 'User' : 'Connor',
        email: email,
        phone: '+1-555-0123',
        drivingLicense: 'DL-CA-987654',
        address: '742 Evergreen Terrace, CA',
        role: email.includes('admin') ? 'ROLE_ADMIN' : 'ROLE_CUSTOMER'
      };
      localStorage.setItem('apex_customer', JSON.stringify(currentCustomer));
      updateAuthUI(true);
      closeModal('authModal');
      showToast(`Signed in successfully as ${currentCustomer.firstName}!`, 'success');
      updateBookingCustomerStatus();
      return true;
    }
    showToast('Sign-in failed. Please verify credentials.', 'error');
    return false;
  }
}

async function handleSignUp(customerData) {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customerData)
    });

    if (res.ok) {
      const data = await res.json();
      currentCustomer = data.customer;
      localStorage.setItem('apex_customer', JSON.stringify(currentCustomer));
      updateAuthUI(true);
      closeModal('authModal');
      showToast(`Account created! Welcome, ${currentCustomer.firstName}!`, 'success');
      updateBookingCustomerStatus();
      return true;
    } else {
      const err = await res.json();
      showToast(err.error || 'Registration failed.', 'error');
      return false;
    }
  } catch (error) {
    currentCustomer = { id: Date.now(), ...customerData };
    delete currentCustomer.password;
    localStorage.setItem('apex_customer', JSON.stringify(currentCustomer));
    updateAuthUI(true);
    closeModal('authModal');
    showToast(`Account created! Welcome, ${currentCustomer.firstName}!`, 'success');
    updateBookingCustomerStatus();
    return true;
  }
}

function handleLogout() {
  currentCustomer = null;
  localStorage.removeItem('apex_customer');
  updateAuthUI(false);
  showToast('You have been signed out.', 'success');
  updateBookingCustomerStatus();
}

function fillDemoLogin(email, password) {
  document.getElementById('signInEmail').value = email;
  document.getElementById('signInPassword').value = password;
}

async function fetchCars() {
  try {
    const res = await fetch('/api/cars');
    if (res.ok) {
      allCars = await res.json();
      if (!allCars || allCars.length === 0) {
        allCars = INITIAL_CARS_FALLBACK;
      }
    } else {
      allCars = INITIAL_CARS_FALLBACK;
    }
  } catch (err) {
    allCars = INITIAL_CARS_FALLBACK;
  }
  renderCars();
}

function renderCars() {
  const carsGrid = document.getElementById('carsGrid');
  if (!carsGrid) return;

  const filtered = allCars.filter(car => {
    const catMatch = (currentCategory === 'ALL' || car.category.toUpperCase() === currentCategory);
    const searchTarget = `${car.brand} ${car.model} ${car.description || ''}`.toLowerCase();
    const queryMatch = !searchQuery || searchTarget.includes(searchQuery.toLowerCase());
    const priceVal = Number(car.pricePerDay);
    const priceMatch = priceVal <= maxPrice;
    return catMatch && queryMatch && priceMatch;
  });

  if (filtered.length === 0) {
    carsGrid.innerHTML = `
      <div class="loading-state">
        <i class="fa-solid fa-car-tunnel" style="font-size: 2.5rem; color: var(--text-dim); margin-bottom: 14px;"></i>
        <p>No vehicles match your search criteria.</p>
        <button class="btn btn-outline btn-sm" style="margin-top: 12px;" onclick="resetFilters()">Reset All Filters</button>
      </div>
    `;
    return;
  }

  carsGrid.innerHTML = filtered.map(car => `
    <div class="car-card">
      <div class="car-image-box">
        <img src="${car.imageUrl || 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80'}" alt="${car.brand} ${car.model}" loading="lazy">
        <span class="car-category-pill">${car.category}</span>
        <span class="car-status-pill ${car.available ? 'status-avail' : 'status-unavail'}">
          ${car.available ? '● Available' : 'Reserved'}
        </span>
      </div>

      <div class="car-content">
        <div class="car-title-row">
          <h3 class="car-brand-model">${car.brand} ${car.model}</h3>
          <span class="car-year">${car.year}</span>
        </div>

        <p class="car-description">${car.description || 'Experience cutting-edge luxury with high-performance engineering.'}</p>

        <div class="car-specs">
          <div class="spec-item"><i class="fa-solid fa-users"></i> ${car.seats || 5} Seats</div>
          <div class="spec-item"><i class="fa-solid fa-gear"></i> ${car.transmission || 'Automatic'}</div>
          <div class="spec-item"><i class="fa-solid fa-gas-pump"></i> ${car.fuelType || 'Petrol'}</div>
        </div>

        <div class="car-footer">
          <div class="car-price">
            <span class="rate-amount">${Number(car.pricePerDay).toFixed(0)} DT <span>/jour</span></span>
          </div>
          <button class="btn ${car.available ? 'btn-primary' : 'btn-outline'}" onclick="openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
            ${car.available ? '<i class="fa-solid fa-bolt"></i> Rent Now' : 'Reserved'}
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function resetFilters() {
  currentCategory = 'ALL';
  searchQuery = '';
  maxPrice = 600;
  document.getElementById('carSearchInput').value = '';
  document.getElementById('priceRange').value = 600;
  document.getElementById('priceDisplay').textContent = '600 DT / jour';
  document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
  document.querySelector('.cat-tab[data-category="ALL"]').classList.add('active');
  renderCars();
}

function filterCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('.cat-tab').forEach(t => {
    t.classList.toggle('active', t.getAttribute('data-category') === cat);
  });
  renderCars();
}

function openBookingModal(carId) {
  const car = allCars.find(c => c.id === carId);
  if (!car) return;

  selectedCarForBooking = car;
  document.getElementById('bookingCarId').value = car.id;
  document.getElementById('modalCarTitle').textContent = `${car.brand} ${car.model}`;
  document.getElementById('modalCarCategory').textContent = car.category;
  document.getElementById('modalCarDesc').textContent = car.description;
  document.getElementById('modalCarSeats').textContent = `${car.seats || 5} Seats`;
  document.getElementById('modalCarTransmission').textContent = car.transmission || 'Automatic';
  document.getElementById('modalCarFuel').textContent = car.fuelType || 'Hybrid';
  document.getElementById('modalCarYear').textContent = car.year;
  document.getElementById('modalCarPrice').textContent = `${Number(car.pricePerDay).toFixed(0)} DT`;
  document.getElementById('modalCarImage').src = car.imageUrl;

  calculateBookingPrice();
  updateBookingCustomerStatus();
  openModal('bookingModal');
}

function updateBookingCustomerStatus() {
  const statusContainer = document.getElementById('bookingCustomerStatus');
  if (!statusContainer) return;

  if (currentCustomer) {
    statusContainer.innerHTML = `
      <div class="note-success">
        <i class="fa-solid fa-circle-check"></i>
        <span>Booking as <strong>${currentCustomer.firstName} ${currentCustomer.lastName || ''}</strong> (${currentCustomer.email})</span>
      </div>
    `;
  } else {
    statusContainer.innerHTML = `
      <div class="note-alert">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <span>You are currently not signed in. <a href="#" style="text-decoration: underline; font-weight: 700; color: inherit;" onclick="promptSignInBeforeBooking(event)">Sign in or register</a> to complete your booking.</span>
      </div>
    `;
  }
}

function promptSignInBeforeBooking(e) {
  if (e) e.preventDefault();
  closeModal('bookingModal');
  openModal('authModal');
}

function calculateBookingPrice() {
  if (!selectedCarForBooking) return;

  const startDateVal = document.getElementById('bookingStartDate').value;
  const endDateVal = document.getElementById('bookingEndDate').value;

  if (!startDateVal || !endDateVal) return;

  const start = new Date(startDateVal);
  const end = new Date(endDateVal);

  const diffTime = end.getTime() - start.getTime();
  let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  if (diffDays <= 0) diffDays = 1;

  const dailyRate = Number(selectedCarForBooking.pricePerDay);
  const subtotal = diffDays * dailyRate;

  // Calculate selected extras
  let extrasPerDay = 0;
  document.querySelectorAll('.extra-checkbox:checked').forEach(cb => {
    extrasPerDay += Number(cb.dataset.price || 0);
  });
  const totalExtras = diffDays * extrasPerDay;
  const grandTotal = subtotal + totalExtras;

  document.getElementById('calcDuration').textContent = `${diffDays} Jour${diffDays > 1 ? 's' : ''}`;
  document.getElementById('calcSubtotal').textContent = `${subtotal.toFixed(0)} DT`;

  const rowExtras = document.getElementById('rowExtras');
  if (rowExtras) {
    if (totalExtras > 0) {
      rowExtras.style.display = 'flex';
      document.getElementById('calcExtras').textContent = `+${totalExtras.toFixed(0)} DT`;
    } else {
      rowExtras.style.display = 'none';
    }
  }

  document.getElementById('calcTotalPrice').textContent = `${grandTotal.toFixed(0)} DT`;
}

async function handleBookingSubmit(e) {
  e.preventDefault();

  if (!currentCustomer) {
    showToast('Please sign in to confirm your reservation.', 'error');
    openModal('authModal');
    return;
  }

  const carId = document.getElementById('bookingCarId').value;
  const pickupLocation = document.getElementById('bookingPickupLocation').value;
  const returnLocation = document.getElementById('bookingReturnLocation').value;
  const startDate = document.getElementById('bookingStartDate').value;
  const endDate = document.getElementById('bookingEndDate').value;

  const start = new Date(startDate);
  const end = new Date(endDate);
  let days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
  if (days <= 0) days = 1;

  // Calculate extras
  let extrasPerDay = 0;
  document.querySelectorAll('.extra-checkbox:checked').forEach(cb => {
    extrasPerDay += Number(cb.dataset.price || 0);
  });
  const subtotal = days * Number(selectedCarForBooking.pricePerDay);
  const totalPrice = subtotal + (days * extrasPerDay);

  const bookingPayload = {
    customer: { id: currentCustomer.id },
    car: { id: Number(carId) },
    startDate: startDate,
    endDate: endDate,
    totalPrice: totalPrice,
    status: 'CONFIRMED',
    pickupLocation: pickupLocation,
    returnLocation: returnLocation
  };

  try {
    const res = await fetch('/api/rentals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bookingPayload)
    });

    if (res.ok) {
      const savedRental = await res.json();
      closeModal('bookingModal');
      showToast(`Réservation #${savedRental.id || 'CONFIRMÉE'} effectuée avec succès !`, 'success');
      saveLocalBooking(savedRental);
      openVoucherModal(savedRental);
    } else {
      const err = await res.json();
      showToast(err.error || 'Failed to place reservation.', 'error');
    }
  } catch (error) {
    const mockRental = {
      id: Math.floor(1000 + Math.random() * 9000),
      car: selectedCarForBooking,
      customer: currentCustomer,
      startDate,
      endDate,
      totalPrice,
      status: 'CONFIRMED',
      pickupLocation,
      returnLocation,
      createdAt: new Date().toISOString()
    };
    saveLocalBooking(mockRental);
    closeModal('bookingModal');
    showToast(`Réservation #${mockRental.id} confirmée !`, 'success');
    openVoucherModal(mockRental);
  }
}

function saveLocalBooking(rental) {
  const bookings = getLocalBookings();
  bookings.unshift(rental);
  localStorage.setItem('apex_bookings', JSON.stringify(bookings));
}

function getLocalBookings() {
  try {
    return JSON.parse(localStorage.getItem('apex_bookings') || '[]');
  } catch (e) {
    return [];
  }
}

async function openMyBookingsModal() {
  if (!currentCustomer) {
    openModal('authModal');
    return;
  }

  document.getElementById('dashCustomerName').textContent = `${currentCustomer.firstName} ${currentCustomer.lastName || ''}`;
  document.getElementById('dashCustomerEmail').textContent = currentCustomer.email;
  document.getElementById('dashAvatar').textContent = (currentCustomer.firstName || 'U').charAt(0).toUpperCase();

  await loadCustomerBookings();
  openModal('myBookingsModal');
}

async function loadCustomerBookings() {
  const bookingsList = document.getElementById('bookingsList');
  bookingsList.innerHTML = `<div class="spinner"></div>`;

  let bookings = [];
  try {
    const res = await fetch(`/api/rentals/customer/${currentCustomer.id}`);
    if (res.ok) {
      bookings = await res.json();
    }
  } catch (e) {
    // fallback
  }

  if (!bookings || bookings.length === 0) {
    const local = getLocalBookings().filter(b => b.customer && b.customer.id === currentCustomer.id);
    bookings = local;
  }

  if (bookings.length === 0) {
    bookingsList.innerHTML = `
      <div style="text-align: center; padding: 40px 0; color: var(--text-dim);">
        <i class="fa-solid fa-receipt" style="font-size: 2.5rem; margin-bottom: 12px;"></i>
        <p>You have no active reservations yet.</p>
        <button class="btn btn-primary btn-sm" style="margin-top: 14px;" onclick="closeModal('myBookingsModal'); window.location.hash = '#fleet';">Browse Car Fleet</button>
      </div>
    `;
    return;
  }

  bookingsList.innerHTML = bookings.map(b => {
    const car = b.car || selectedCarForBooking || {};
    const isCancelled = b.status === 'CANCELLED';

    return `
      <div class="booking-item-card">
        <div class="booking-item-left">
          <img src="${car.imageUrl || 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80'}" class="booking-item-thumb" alt="${car.brand || 'Car'}">
          <div>
            <div class="booking-item-title">${car.brand || 'Luxury'} ${car.model || 'Vehicle'} <span style="font-size: 0.8rem; color: var(--text-dim); font-weight: normal;">(#${b.id})</span></div>
            <div class="booking-item-dates">
              <i class="fa-regular fa-calendar"></i> ${b.startDate} → ${b.endDate} &nbsp;•&nbsp; 
              <i class="fa-solid fa-location-dot"></i> ${b.pickupLocation || 'Airport'}
            </div>
          </div>
        </div>

        <div class="booking-item-right">
          <div class="booking-item-price">${Number(b.totalPrice || 0).toFixed(0)} DT</div>
          <span class="badge-status ${b.status || 'CONFIRMED'}">${b.status || 'CONFIRMED'}</span>
          <button class="btn btn-outline btn-sm" onclick="showVoucherById(${b.id})" title="Voir le bon officiel">
            <i class="fa-solid fa-file-invoice"></i> Bon
          </button>
          ${!isCancelled ? `
            <button class="btn btn-outline btn-sm" onclick="cancelCustomerBooking(${b.id})" title="Cancel this reservation">
              Annuler
            </button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

async function cancelCustomerBooking(rentalId) {
  if (!confirm(`Are you sure you want to cancel booking #${rentalId}? This will release the vehicle.`)) {
    return;
  }

  try {
    const res = await fetch(`/api/rentals/${rentalId}/cancel`, { method: 'PUT' });
    if (res.ok) {
      showToast(`Reservation #${rentalId} was cancelled.`, 'success');
    }
  } catch (e) {
    // fallback
  }

  const local = getLocalBookings();
  const target = local.find(b => b.id === rentalId);
  if (target) {
    target.status = 'CANCELLED';
    localStorage.setItem('apex_bookings', JSON.stringify(local));
  }

  showToast(`Reservation #${rentalId} cancelled.`, 'success');
  loadCustomerBookings();
}

function setupEventListeners() {
  document.getElementById('btnOpenSignIn').addEventListener('click', () => {
    switchAuthTab('signIn');
    openModal('authModal');
  });

  document.getElementById('btnOpenSignUp').addEventListener('click', () => {
    switchAuthTab('signUp');
    openModal('authModal');
  });

  document.getElementById('btnLogout').addEventListener('click', handleLogout);
  document.getElementById('btnMyBookings').addEventListener('click', openMyBookingsModal);
  document.getElementById('footerBookingsLink').addEventListener('click', (e) => {
    e.preventDefault();
    openMyBookingsModal();
  });
  document.getElementById('footerSignInLink').addEventListener('click', (e) => {
    e.preventDefault();
    if (currentCustomer) {
      openMyBookingsModal();
    } else {
      switchAuthTab('signIn');
      openModal('authModal');
    }
  });

  document.getElementById('btnCloseAuthModal').addEventListener('click', () => closeModal('authModal'));
  document.getElementById('btnCloseBookingModal').addEventListener('click', () => closeModal('bookingModal'));
  document.getElementById('btnCloseMyBookingsModal').addEventListener('click', () => closeModal('myBookingsModal'));
  document.getElementById('btnRefreshBookings').addEventListener('click', loadCustomerBookings);

  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('active');
        overlay.setAttribute('aria-hidden', 'true');
      }
    });
  });

  document.getElementById('tabSignIn').addEventListener('click', () => switchAuthTab('signIn'));
  document.getElementById('tabSignUp').addEventListener('click', () => switchAuthTab('signUp'));

  document.getElementById('formSignIn').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('signInEmail').value.trim();
    const password = document.getElementById('signInPassword').value;
    handleSignIn(email, password);
  });

  const btnGoogleSignIn = document.getElementById('btnGoogleSignIn');
  if (btnGoogleSignIn) {
    btnGoogleSignIn.addEventListener('click', onGoogleSignInClick);
  }

  const formGoogleEmail = document.getElementById('formGoogleEmail');
  if (formGoogleEmail) {
    formGoogleEmail.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('googleInputEmail').value.trim();
      if (email && isValidEmail(email)) {
        sendGoogleVerificationCode(email);
      } else {
        showToast('Please enter a valid Gmail address.', 'error');
      }
    });
  }

  const formGoogleVerify = document.getElementById('formGoogleVerify');
  if (formGoogleVerify) {
    formGoogleVerify.addEventListener('submit', (e) => {
      e.preventDefault();
      let full = '';
      document.querySelectorAll('#otpContainer .otp-input').forEach(i => full += i.value);
      if (full.length < 6) {
        showToast('Please enter the full 6-digit verification code.', 'error');
        return;
      }
      verifyGoogleCode(full);
    });
  }

  const btnOpenGmailModalDirect = document.getElementById('btnOpenGmailModalDirect');
  if (btnOpenGmailModalDirect) {
    btnOpenGmailModalDirect.addEventListener('click', openGmailModal);
  }

  const btnResendGoogleCode = document.getElementById('btnResendGoogleCode');
  if (btnResendGoogleCode) {
    btnResendGoogleCode.addEventListener('click', () => {
      if (googleAuthState.email) {
        sendGoogleVerificationCode(googleAuthState.email);
        showToast('New verification code sent to your Gmail!', 'info');
      }
    });
  }

  const btnBackToAuth = document.getElementById('btnBackToAuth');
  if (btnBackToAuth) {
    btnBackToAuth.addEventListener('click', () => switchAuthTab('signIn'));
  }

  const btnBackToSignInFromEmail = document.getElementById('btnBackToSignInFromEmail');
  if (btnBackToSignInFromEmail) {
    btnBackToSignInFromEmail.addEventListener('click', () => switchAuthTab('signIn'));
  }

  setupOtpInputHandlers();

  document.getElementById('formSignUp').addEventListener('submit', (e) => {
    e.preventDefault();
    const customer = {
      firstName: document.getElementById('regFirstName').value.trim(),
      lastName: document.getElementById('regLastName').value.trim(),
      email: document.getElementById('regEmail').value.trim(),
      phone: document.getElementById('regPhone').value.trim(),
      drivingLicense: document.getElementById('regLicense').value.trim(),
      address: document.getElementById('regAddress').value.trim(),
      password: document.getElementById('regPassword').value
    };
    handleSignUp(customer);
  });

  document.getElementById('formBooking').addEventListener('submit', handleBookingSubmit);

  document.querySelectorAll('.btn-toggle-pwd').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const input = document.getElementById(targetId);
      const icon = btn.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fa-regular fa-eye-slash';
      } else {
        input.type = 'password';
        icon.className = 'fa-regular fa-eye';
      }
    });
  });

  document.querySelectorAll('.cat-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentCategory = tab.getAttribute('data-category');
      renderCars();
    });
  });

  const searchInput = document.getElementById('carSearchInput');
  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    renderCars();
  });

  const priceRange = document.getElementById('priceRange');
  const priceDisplay = document.getElementById('priceDisplay');
  priceRange.addEventListener('input', (e) => {
    maxPrice = Number(e.target.value);
    priceDisplay.textContent = `${maxPrice} DT / jour`;
    renderCars();
  });

  document.getElementById('quickSearchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const cat = document.getElementById('quickCategory').value;
    filterCategory(cat);
    document.getElementById('fleet').scrollIntoView({ behavior: 'smooth' });
  });

  document.getElementById('bookingStartDate').addEventListener('change', calculateBookingPrice);
  document.getElementById('bookingEndDate').addEventListener('change', calculateBookingPrice);

  // Extras checkboxes listeners for real-time recalculation
  document.querySelectorAll('.extra-checkbox').forEach(cb => {
    cb.addEventListener('change', calculateBookingPrice);
  });

  // Admin Dashboard Listeners
  const btnAdmin = document.getElementById('btnAdminPanel');
  if (btnAdmin) btnAdmin.addEventListener('click', openAdminModal);

  const btnCloseAdmin = document.getElementById('btnCloseAdminModal');
  if (btnCloseAdmin) btnCloseAdmin.addEventListener('click', () => closeModal('adminModal'));

  const tabAdminCars = document.getElementById('tabAdminCars');
  if (tabAdminCars) tabAdminCars.addEventListener('click', () => switchAdminTab('cars'));

  const tabAdminBookings = document.getElementById('tabAdminBookings');
  if (tabAdminBookings) tabAdminBookings.addEventListener('click', () => switchAdminTab('bookings'));

  const btnAddCar = document.getElementById('btnOpenAddCarModal');
  if (btnAddCar) btnAddCar.addEventListener('click', openAddCarModal);

  const btnCloseCarForm = document.getElementById('btnCloseCarFormModal');
  if (btnCloseCarForm) btnCloseCarForm.addEventListener('click', () => closeModal('carFormModal'));

  const formCarAdmin = document.getElementById('formCarAdmin');
  if (formCarAdmin) formCarAdmin.addEventListener('submit', handleSaveAdminCar);

  const btnRefreshAdmin = document.getElementById('btnRefreshAdminBookings');
  if (btnRefreshAdmin) btnRefreshAdmin.addEventListener('click', renderAdminBookings);

  // Voucher Modal Listeners
  const btnCloseVoucher = document.getElementById('btnCloseVoucherModal');
  if (btnCloseVoucher) btnCloseVoucher.addEventListener('click', () => closeModal('voucherModal'));

  const btnCloseVoucherBtn = document.getElementById('btnCloseVoucherBtn');
  if (btnCloseVoucherBtn) btnCloseVoucherBtn.addEventListener('click', () => closeModal('voucherModal'));

  document.getElementById('btnExpBrowse').addEventListener('click', () => {
    document.getElementById('fleet').scrollIntoView({ behavior: 'smooth' });
  });

  document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
      const body = header.nextElementSibling;
      const isOpen = body.classList.contains('open');

      document.querySelectorAll('.accordion-body').forEach(b => b.classList.remove('open'));
      document.querySelectorAll('.accordion-header').forEach(h => h.classList.remove('active'));

      if (!isOpen) {
        body.classList.add('open');
        header.classList.add('active');
      }
    });
  });
}

function switchAuthTab(tab) {
  const tabSignIn = document.getElementById('tabSignIn');
  const tabSignUp = document.getElementById('tabSignUp');
  const panelSignIn = document.getElementById('panelSignIn');
  const panelSignUp = document.getElementById('panelSignUp');
  const panelGoogleEmail = document.getElementById('panelGoogleEmail');
  const panelGoogleVerify = document.getElementById('panelGoogleVerify');
  const authTabsContainer = document.querySelector('.auth-tabs');

  if (panelGoogleEmail) panelGoogleEmail.style.display = 'none';
  if (panelGoogleVerify) panelGoogleVerify.style.display = 'none';
  if (authTabsContainer) authTabsContainer.style.display = 'flex';

  if (tab === 'signIn') {
    tabSignIn.classList.add('active');
    tabSignUp.classList.remove('active');
    panelSignIn.classList.add('active');
    panelSignIn.style.display = '';
    panelSignUp.classList.remove('active');
    panelSignUp.style.display = 'none';
  } else {
    tabSignUp.classList.add('active');
    tabSignIn.classList.remove('active');
    panelSignUp.classList.add('active');
    panelSignUp.style.display = '';
    panelSignIn.classList.remove('active');
    panelSignIn.style.display = 'none';
  }
}

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (modalId === 'authModal') {
      switchAuthTab('signIn');
    }
  }
}

function setupDateDefaults() {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const returnDate = new Date(today);
  returnDate.setDate(returnDate.getDate() + 4);

  const formatDate = (d) => d.toISOString().split('T')[0];

  const quickStart = document.getElementById('quickStartDate');
  const quickEnd = document.getElementById('quickEndDate');
  const bookingStart = document.getElementById('bookingStartDate');
  const bookingEnd = document.getElementById('bookingEndDate');

  if (quickStart) {
    quickStart.value = formatDate(tomorrow);
    quickStart.min = formatDate(today);
  }
  if (quickEnd) {
    quickEnd.value = formatDate(returnDate);
    quickEnd.min = formatDate(tomorrow);
  }
  if (bookingStart) {
    bookingStart.value = formatDate(tomorrow);
    bookingStart.min = formatDate(today);
  }
  if (bookingEnd) {
    bookingEnd.value = formatDate(returnDate);
    bookingEnd.min = formatDate(tomorrow);
  }
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  let icon = 'fa-solid fa-circle-info';
  if (type === 'success') icon = 'fa-solid fa-circle-check';
  if (type === 'error') icon = 'fa-solid fa-triangle-exclamation';

  toast.innerHTML = `<i class="${icon}"></i> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/* =====================================================================
   ADMIN DASHBOARD & VOUCHER GENERATOR LOGIC
   ===================================================================== */
let adminBookings = [];

function openAdminModal() {
  if (!currentCustomer || (currentCustomer.role !== 'ROLE_ADMIN' && currentCustomer.email !== 'admin@carrent.com')) {
    showToast('Accès réservé aux administrateurs.', 'error');
    return;
  }
  renderAdminCars();
  renderAdminBookings();
  openModal('adminModal');
}

function switchAdminTab(tab) {
  const tabCars = document.getElementById('tabAdminCars');
  const tabBookings = document.getElementById('tabAdminBookings');
  const panelCars = document.getElementById('panelAdminCars');
  const panelBookings = document.getElementById('panelAdminBookings');

  if (tab === 'cars') {
    tabCars.classList.add('active');
    tabBookings.classList.remove('active');
    panelCars.classList.add('active');
    panelBookings.classList.remove('active');
    renderAdminCars();
  } else {
    tabBookings.classList.add('active');
    tabCars.classList.remove('active');
    panelBookings.classList.add('active');
    panelCars.classList.remove('active');
    renderAdminBookings();
  }
}

function renderAdminCars() {
  const tbody = document.getElementById('adminCarsList');
  if (!tbody) return;

  tbody.innerHTML = allCars.map(c => `
    <tr>
      <td>
        <div class="table-car-cell">
          <img src="${c.imageUrl}" class="table-car-thumb" alt="${c.brand}">
          <strong>${c.brand} ${c.model}</strong>
        </div>
      </td>
      <td><span class="badge" style="font-size: 0.75rem;">${c.category}</span></td>
      <td><code>${c.licensePlate}</code></td>
      <td><strong>${Number(c.pricePerDay).toFixed(0)} DT</strong></td>
      <td>${c.fuelType} / ${c.transmission}</td>
      <td>
        <button class="btn btn-sm ${c.available ? 'btn-primary' : 'btn-outline'}" onclick="toggleCarAvailability(${c.id})">
          ${c.available ? '● En Ligne' : '○ Indisponible'}
        </button>
      </td>
      <td>
        <div style="display: flex; gap: 6px;">
          <button class="btn btn-outline btn-sm" onclick="openEditCarModal(${c.id})" title="Modifier">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn btn-outline btn-sm" onclick="deleteAdminCar(${c.id})" title="Supprimer" style="color: var(--rose);">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

async function toggleCarAvailability(carId) {
  const car = allCars.find(c => c.id === carId);
  if (!car) return;
  car.available = !car.available;

  try {
    await fetch(`/api/cars/${carId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(car)
    });
  } catch (e) {}

  renderAdminCars();
  renderCars();
  showToast(`Disponibilité mise à jour pour ${car.brand} ${car.model}.`, 'success');
}

function openAddCarModal() {
  document.getElementById('carFormTitle').textContent = 'Ajouter un Véhicule';
  document.getElementById('adminCarId').value = '';
  document.getElementById('adminCarBrand').value = '';
  document.getElementById('adminCarModel').value = '';
  document.getElementById('adminCarCategory').value = 'LUXURY';
  document.getElementById('adminCarYear').value = 2024;
  document.getElementById('adminCarPlate').value = '';
  document.getElementById('adminCarPrice').value = '';
  document.getElementById('adminCarFuel').value = 'Petrol';
  document.getElementById('adminCarTransmission').value = 'Automatic';
  document.getElementById('adminCarImageUrl').value = 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80';
  document.getElementById('adminCarDesc').value = '';
  openModal('carFormModal');
}

function openEditCarModal(carId) {
  const car = allCars.find(c => c.id === carId);
  if (!car) return;

  document.getElementById('carFormTitle').textContent = 'Modifier le Véhicule';
  document.getElementById('adminCarId').value = car.id;
  document.getElementById('adminCarBrand').value = car.brand;
  document.getElementById('adminCarModel').value = car.model;
  document.getElementById('adminCarCategory').value = car.category;
  document.getElementById('adminCarYear').value = car.year;
  document.getElementById('adminCarPlate').value = car.licensePlate;
  document.getElementById('adminCarPrice').value = car.pricePerDay;
  document.getElementById('adminCarFuel').value = car.fuelType;
  document.getElementById('adminCarTransmission').value = car.transmission;
  document.getElementById('adminCarImageUrl').value = car.imageUrl;
  document.getElementById('adminCarDesc').value = car.description || '';
  openModal('carFormModal');
}

async function handleSaveAdminCar(e) {
  e.preventDefault();
  const id = document.getElementById('adminCarId').value;
  const carData = {
    brand: document.getElementById('adminCarBrand').value.trim(),
    model: document.getElementById('adminCarModel').value.trim(),
    category: document.getElementById('adminCarCategory').value,
    year: Number(document.getElementById('adminCarYear').value),
    licensePlate: document.getElementById('adminCarPlate').value.trim(),
    pricePerDay: Number(document.getElementById('adminCarPrice').value),
    fuelType: document.getElementById('adminCarFuel').value,
    transmission: document.getElementById('adminCarTransmission').value,
    imageUrl: document.getElementById('adminCarImageUrl').value.trim(),
    description: document.getElementById('adminCarDesc').value.trim(),
    available: true,
    seats: 5
  };

  if (id) {
    try {
      await fetch(`/api/cars/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(carData)
      });
    } catch (e) {}

    const index = allCars.findIndex(c => c.id === Number(id));
    if (index !== -1) allCars[index] = { ...allCars[index], ...carData };
    showToast('Véhicule modifié avec succès !', 'success');
  } else {
    const newCar = { id: Date.now(), ...carData };
    try {
      const res = await fetch('/api/cars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(carData)
      });
      if (res.ok) {
        const created = await res.json();
        newCar.id = created.id || newCar.id;
      }
    } catch (e) {}

    allCars.unshift(newCar);
    showToast('Nouveau véhicule ajouté au catalogue !', 'success');
  }

  closeModal('carFormModal');
  renderAdminCars();
  renderCars();
}

async function deleteAdminCar(carId) {
  if (!confirm('Êtes-vous sûr de vouloir supprimer définitivement ce véhicule du parc ?')) return;

  try {
    await fetch(`/api/cars/${carId}`, { method: 'DELETE' });
  } catch (e) {}

  allCars = allCars.filter(c => c.id !== carId);
  renderAdminCars();
  renderCars();
  showToast('Véhicule supprimé du parc.', 'success');
}

async function renderAdminBookings() {
  const tbody = document.getElementById('adminBookingsList');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;"><div class="spinner"></div></td></tr>';

  let list = [];
  try {
    const res = await fetch('/api/rentals');
    if (res.ok) list = await res.json();
  } catch (e) {}

  if (!list || list.length === 0) {
    list = getLocalBookings();
  }

  adminBookings = list;

  if (list.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--text-dim); padding: 24px;">Aucune réservation enregistrée.</td></tr>';
    return;
  }

  tbody.innerHTML = list.map(b => {
    const customer = b.customer || {};
    const car = b.car || {};
    return `
      <tr>
        <td><strong>#${b.id}</strong></td>
        <td>
          <strong>${customer.firstName || 'Client'} ${customer.lastName || ''}</strong><br>
          <small style="color: var(--text-dim);">${customer.email || 'N/A'}</small>
        </td>
        <td>${car.brand || 'Auto'} ${car.model || ''}</td>
        <td>${b.startDate} → ${b.endDate}</td>
        <td>${b.pickupLocation || 'Tunis'}</td>
        <td><strong style="color: var(--accent);">${Number(b.totalPrice || 0).toFixed(0)} DT</strong></td>
        <td><span class="badge-status ${b.status || 'CONFIRMED'}">${b.status || 'CONFIRMED'}</span></td>
        <td>
          <select class="status-select" onchange="updateBookingStatusAdmin(${b.id}, this.value)">
            <option value="CONFIRMED" ${b.status === 'CONFIRMED' ? 'selected' : ''}>Confirmée</option>
            <option value="COMPLETED" ${b.status === 'COMPLETED' ? 'selected' : ''}>Terminée</option>
            <option value="CANCELLED" ${b.status === 'CANCELLED' ? 'selected' : ''}>Annulée</option>
          </select>
        </td>
      </tr>
    `;
  }).join('');
}

async function updateBookingStatusAdmin(rentalId, newStatus) {
  try {
    if (newStatus === 'CANCELLED') {
      await fetch(`/api/rentals/${rentalId}/cancel`, { method: 'PUT' });
    } else {
      await fetch(`/api/rentals/${rentalId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
    }
  } catch (e) {}

  const local = getLocalBookings();
  const target = local.find(b => b.id === rentalId);
  if (target) {
    target.status = newStatus;
    localStorage.setItem('apex_bookings', JSON.stringify(local));
  }

  showToast(`Statut de la réservation #${rentalId} mis à jour : ${newStatus}`, 'success');
  renderAdminBookings();
}

function showVoucherById(rentalId) {
  const local = getLocalBookings();
  const rental = local.find(b => b.id === rentalId) || adminBookings.find(b => b.id === rentalId);
  if (rental) {
    openVoucherModal(rental);
  } else {
    showToast('Réservation introuvable.', 'error');
  }
}

function openVoucherModal(rental) {
  if (!rental) return;
  const customer = rental.customer || currentCustomer || {};
  const car = rental.car || selectedCarForBooking || {};

  document.getElementById('voucherRef').textContent = `RÉF #${rental.id || '2026'}`;
  document.getElementById('vouchCustomerName').textContent = `${customer.firstName || 'Client'} ${customer.lastName || ''}`;
  document.getElementById('vouchCustomerEmail').textContent = customer.email || 'N/A';
  document.getElementById('vouchCustomerLicense').textContent = customer.drivingLicense || 'DL-TUN-123456';
  document.getElementById('vouchCustomerPhone').textContent = customer.phone || '+216 71 000 000';

  document.getElementById('vouchCarTitle').textContent = `${car.brand || 'Véhicule'} ${car.model || ''} (${car.year || 2024})`;
  document.getElementById('vouchCarPlate').textContent = car.licensePlate || '220-TUN-0000';
  document.getElementById('vouchCarSpecs').textContent = `${car.transmission || 'Automatique'} • ${car.fuelType || 'Essence'}`;

  document.getElementById('vouchStartDate').textContent = rental.startDate || 'N/A';
  document.getElementById('vouchEndDate').textContent = rental.endDate || 'N/A';
  
  const start = new Date(rental.startDate);
  const end = new Date(rental.endDate);
  let days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
  if (isNaN(days) || days <= 0) days = 3;
  document.getElementById('vouchDays').textContent = `${days} Jours`;

  document.getElementById('vouchPickupLoc').textContent = rental.pickupLocation || 'Aéroport Tunis-Carthage (TUN)';
  document.getElementById('vouchTotalPrice').textContent = `${Number(rental.totalPrice || 0).toFixed(0)} DT`;

  openModal('voucherModal');
}

/* ============================================================
   GOOGLE SIGN-IN & GMAIL OTP VERIFICATION FLOW
   ============================================================ */
let googleAuthState = {
  email: '',
  code: '',
  timer: null,
  countdown: 30
};

function isValidEmail(email) {
  return Boolean(email && email.includes('@') && email.includes('.'));
}

function onGoogleSignInClick() {
  const emailInput = document.getElementById('signInEmail');
  const enteredEmail = emailInput ? emailInput.value.trim() : '';

  if (enteredEmail && isValidEmail(enteredEmail)) {
    sendGoogleVerificationCode(enteredEmail);
  } else {
    showGoogleEmailStep(enteredEmail);
  }
}

function showGoogleEmailStep(prefill = '') {
  const panelSignIn = document.getElementById('panelSignIn');
  const panelSignUp = document.getElementById('panelSignUp');
  const panelGoogleEmail = document.getElementById('panelGoogleEmail');
  const panelGoogleVerify = document.getElementById('panelGoogleVerify');
  const authTabsContainer = document.querySelector('.auth-tabs');

  if (panelSignIn) { panelSignIn.style.display = 'none'; panelSignIn.classList.remove('active'); }
  if (panelSignUp) { panelSignUp.style.display = 'none'; panelSignUp.classList.remove('active'); }
  if (panelGoogleVerify) { panelGoogleVerify.style.display = 'none'; panelGoogleVerify.classList.remove('active'); }
  if (authTabsContainer) authTabsContainer.style.display = 'none';

  if (panelGoogleEmail) {
    panelGoogleEmail.style.display = 'block';
    panelGoogleEmail.classList.add('active');
    const input = document.getElementById('googleInputEmail');
    if (input) {
      input.value = prefill;
      input.focus();
    }
  }
}

async function sendGoogleVerificationCode(email) {
  let code = Math.floor(100000 + Math.random() * 900000).toString();
  try {
    const res = await fetch('/api/auth/google-send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.code) code = data.code;
      if (data.emailSent) {
        showToast(`Code envoyé directement à ${email} ! Vérifiez votre boîte de réception Gmail.`, 'success');
      } else {
        showToast(`Code généré pour ${email} !`, 'info');
      }
    }
  } catch (err) {
    console.warn('Backend send-code offline, running locally:', err);
  }

  googleAuthState.email = email;
  googleAuthState.code = code;

  showGoogleVerifyStep(email, code);
  showGmailNotification(email, code);
}

function showGoogleVerifyStep(email, code) {
  const panelSignIn = document.getElementById('panelSignIn');
  const panelSignUp = document.getElementById('panelSignUp');
  const panelGoogleEmail = document.getElementById('panelGoogleEmail');
  const panelGoogleVerify = document.getElementById('panelGoogleVerify');
  const authTabsContainer = document.querySelector('.auth-tabs');

  if (panelSignIn) { panelSignIn.style.display = 'none'; panelSignIn.classList.remove('active'); }
  if (panelSignUp) { panelSignUp.style.display = 'none'; panelSignUp.classList.remove('active'); }
  if (panelGoogleEmail) { panelGoogleEmail.style.display = 'none'; panelGoogleEmail.classList.remove('active'); }
  if (authTabsContainer) authTabsContainer.style.display = 'none';

  if (panelGoogleVerify) {
    panelGoogleVerify.style.display = 'block';
    panelGoogleVerify.classList.add('active');
    const targetEmailEl = document.getElementById('googleTargetEmail');
    if (targetEmailEl) targetEmailEl.textContent = email;

    const otpInputs = document.querySelectorAll('#otpContainer .otp-input');
    otpInputs.forEach(inp => inp.value = '');
    if (otpInputs[0]) otpInputs[0].focus();

    startResendCountdown();
  }
}

function startResendCountdown() {
  if (googleAuthState.timer) clearInterval(googleAuthState.timer);
  googleAuthState.countdown = 30;
  const countdownEl = document.getElementById('resendCountdown');
  const resendBtn = document.getElementById('btnResendGoogleCode');

  if (countdownEl) countdownEl.textContent = `(${googleAuthState.countdown}s)`;
  if (resendBtn) resendBtn.disabled = true;

  googleAuthState.timer = setInterval(() => {
    googleAuthState.countdown--;
    if (countdownEl) {
      if (googleAuthState.countdown > 0) {
        countdownEl.textContent = `(${googleAuthState.countdown}s)`;
      } else {
        countdownEl.textContent = '';
        if (resendBtn) resendBtn.disabled = false;
        clearInterval(googleAuthState.timer);
      }
    }
  }, 1000);
}

function showGmailNotification(email, code) {
  const toast = document.getElementById('gmailNotificationToast');
  const toastCode = document.getElementById('gmailToastCode');
  const modalSubject = document.getElementById('gmailModalCodeSubject');
  const modalRecipient = document.getElementById('gmailModalRecipient');
  const modalCodeBox = document.getElementById('gmailModalCodeBox');

  if (toastCode) toastCode.textContent = code;
  if (modalSubject) modalSubject.textContent = code;
  if (modalRecipient) modalRecipient.textContent = email;

  if (modalCodeBox) {
    modalCodeBox.innerHTML = code.split('').map(d => `<span>${d}</span>`).join('');
  }

  if (toast) {
    toast.style.display = 'block';
  }

  playNotificationChime();
}

function hideGmailNotification() {
  const toast = document.getElementById('gmailNotificationToast');
  if (toast) toast.style.display = 'none';
}

function openGmailModal() {
  openModal('gmailInboxModal');
}

function playNotificationChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch (e) {
    // Ignore audio errors if context blocked
  }
}

function autoFillGoogleCode() {
  const code = googleAuthState.code;
  if (!code) return;

  const otpInputs = document.querySelectorAll('#otpContainer .otp-input');
  otpInputs.forEach((inp, idx) => {
    inp.value = code[idx] || '';
  });

  hideGmailNotification();
  closeModal('gmailInboxModal');

  verifyGoogleCode(code);
}

async function verifyGoogleCode(enteredCode) {
  if (enteredCode !== googleAuthState.code) {
    showToast('Code de vérification incorrect. Regardez dans Gmail.', 'error');
    return;
  }

  const email = googleAuthState.email;
  try {
    const res = await fetch('/api/auth/google-verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, code: enteredCode })
    });

    if (res.ok) {
      const data = await res.json();
      currentCustomer = data.customer;
    } else {
      currentCustomer = createLocalGoogleCustomer(email);
    }
  } catch (err) {
    currentCustomer = createLocalGoogleCustomer(email);
  }

  localStorage.setItem('apex_customer', JSON.stringify(currentCustomer));
  updateAuthUI(true);
  closeModal('authModal');
  closeModal('gmailInboxModal');
  hideGmailNotification();
  switchAuthTab('signIn');

  showToast(`Connecté avec succès via Google (${email}) !`, 'success');
  updateBookingCustomerStatus();
}

function createLocalGoogleCustomer(email) {
  const nameParts = (email.split('@')[0] || 'Google User').replace(/[^a-zA-Z]/g, ' ').trim().split(/\s+/);
  const firstName = (nameParts[0] || 'Google').charAt(0).toUpperCase() + (nameParts[0] || 'Google').slice(1);
  const lastName = (nameParts[1] || 'User').charAt(0).toUpperCase() + (nameParts[1] || 'User').slice(1);
  return {
    id: Date.now(),
    firstName,
    lastName,
    email: email,
    phone: '+216 20 000 000',
    drivingLicense: 'TN-G-' + Math.floor(100000 + Math.random() * 900000),
    address: 'Tunis, Tunisie',
    role: 'ROLE_CUSTOMER'
  };
}

function setupOtpInputHandlers() {
  const inputs = document.querySelectorAll('#otpContainer .otp-input');
  inputs.forEach((input, index) => {
    input.addEventListener('input', (e) => {
      const val = e.target.value.replace(/[^0-9]/g, '');
      e.target.value = val ? val[val.length - 1] : '';
      if (val && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
      checkAutoSubmitOtp();
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !input.value && index > 0) {
        inputs[index - 1].focus();
      }
    });

    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasteData = (e.clipboardData || window.clipboardData).getData('text').replace(/[^0-9]/g, '');
      if (pasteData) {
        inputs.forEach((inp, i) => {
          inp.value = pasteData[i] || '';
        });
        if (pasteData.length >= 6) {
          checkAutoSubmitOtp();
        } else if (inputs[pasteData.length]) {
          inputs[pasteData.length].focus();
        }
      }
    });
  });

  function checkAutoSubmitOtp() {
    let full = '';
    inputs.forEach(i => full += i.value);
    if (full.length === 6) {
      verifyGoogleCode(full);
    }
  }
}

// Global browser window bindings
window.onGoogleSignInClick = onGoogleSignInClick;
window.showGoogleEmailStep = showGoogleEmailStep;
window.sendGoogleVerificationCode = sendGoogleVerificationCode;
window.showGoogleVerifyStep = showGoogleVerifyStep;
window.showGmailNotification = showGmailNotification;
window.hideGmailNotification = hideGmailNotification;
window.openGmailModal = openGmailModal;
window.autoFillGoogleCode = autoFillGoogleCode;
window.verifyGoogleCode = verifyGoogleCode;
