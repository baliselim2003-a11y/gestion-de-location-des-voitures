@echo off
title ApexDrive Spring Boot Server
cd /d "%~dp0"
echo ====================================================================
echo   Starting ApexDrive with Spring Boot (IntelliJ Maven)...
echo ====================================================================
"C:\Program Files\JetBrains\IntelliJ IDEA 2026.2.3\plugins\maven-plugin\lib\maven3\bin\mvn.cmd" spring-boot:run
pause
