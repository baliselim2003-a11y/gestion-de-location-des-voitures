-- =====================================================================
-- CAR RENTAL MANAGEMENT SYSTEM - DATABASE SCHEMA (DDL)
-- =====================================================================
-- Compatible with MySQL 8+, PostgreSQL, and H2 Database
-- =====================================================================

DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS rentals;
DROP TABLE IF EXISTS cars;
DROP TABLE IF EXISTS customers;

-- ---------------------------------------------------------------------
-- 1. CUSTOMERS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE customers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    driving_license VARCHAR(50) NOT NULL UNIQUE,
    address VARCHAR(255),
    role VARCHAR(30) DEFAULT 'ROLE_CUSTOMER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- 2. CARS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE cars (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    brand VARCHAR(80) NOT NULL,
    model VARCHAR(80) NOT NULL,
    category VARCHAR(50) NOT NULL, -- SUV, SEDAN, LUXURY, SPORTS, ELECTRIC, COMPACT
    year INT NOT NULL,
    license_plate VARCHAR(30) NOT NULL UNIQUE,
    price_per_day DECIMAL(10, 2) NOT NULL,
    fuel_type VARCHAR(40) NOT NULL, -- Petrol, Diesel, Electric, Hybrid
    transmission VARCHAR(30) NOT NULL, -- Automatic, Manual
    seats INT NOT NULL DEFAULT 5,
    image_url VARCHAR(500),
    available BOOLEAN NOT NULL DEFAULT TRUE,
    description TEXT
);

-- ---------------------------------------------------------------------
-- 3. RENTALS TABLE (Reservations)
-- ---------------------------------------------------------------------
CREATE TABLE rentals (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    car_id BIGINT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(30) DEFAULT 'PENDING', -- PENDING, CONFIRMED, COMPLETED, CANCELLED
    pickup_location VARCHAR(150) NOT NULL,
    return_location VARCHAR(150) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rental_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    CONSTRAINT fk_rental_car FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- 4. PAYMENTS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    rental_id BIGINT NOT NULL UNIQUE,
    amount DECIMAL(10, 2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method VARCHAR(50) NOT NULL, -- CREDIT_CARD, PAYPAL, STRIPE, CASH
    payment_status VARCHAR(40) NOT NULL DEFAULT 'COMPLETED', -- COMPLETED, PENDING, REFUNDED, FAILED
    CONSTRAINT fk_payment_rental FOREIGN KEY (rental_id) REFERENCES rentals(id) ON DELETE CASCADE
);

-- Indexes for performance
CREATE INDEX idx_customer_email ON customers(email);
CREATE INDEX idx_car_category ON cars(category);
CREATE INDEX idx_car_available ON cars(available);
CREATE INDEX idx_rental_customer ON rentals(customer_id);
CREATE INDEX idx_rental_car ON rentals(car_id);
CREATE INDEX idx_rental_status ON rentals(status);
