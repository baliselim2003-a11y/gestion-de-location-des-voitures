/**
 * APEXDRIVE CAR RENTAL - STANDALONE REST API & WEB SERVER
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 8080;
const STATIC_DIR = path.join(__dirname, 'src', 'main', 'resources', 'static');

let activeVerificationCodes = new Map();

let nodemailer = null;
try {
  nodemailer = require('nodemailer');
} catch (e) {}

function getMailConfig() {
  const configPath = path.join(__dirname, 'mail.config.json');
  if (fs.existsSync(configPath)) {
    try {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    } catch (e) {}
  }
  return {
    user: process.env.GMAIL_USER || '',
    pass: process.env.GMAIL_APP_PASS || ''
  };
}

async function sendRealEmail(toEmail, code) {
  const mailConfig = getMailConfig();
  if (!nodemailer || !mailConfig.user || !mailConfig.pass) {
    console.log(`[Email Simulation] Verification code for ${toEmail}: ${code}`);
    return { success: false, simulated: true, code };
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: mailConfig.user,
      pass: mailConfig.pass.replace(/\s+/g, '')
    }
  });

  const mailOptions = {
    from: `"ApexDrive Security" <${mailConfig.user}>`,
    to: toEmail,
    subject: `Google Verification Code: ${code}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 24px; border: 1px solid #e0e0e0; border-radius: 12px; background: #ffffff;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: #202124; margin: 8px 0;">Google Account Verification</h2>
          <p style="color: #5f6368; font-size: 14px; margin: 0;">ApexDrive Luxury Car Rental</p>
        </div>
        <p style="color: #3c4043; font-size: 15px; line-height: 1.5;">Hi,</p>
        <p style="color: #3c4043; font-size: 15px; line-height: 1.5;">Someone is attempting to sign in to <strong>ApexDrive Car Rental</strong> using your Google Account (<strong>${toEmail}</strong>).</p>
        <p style="color: #3c4043; font-size: 15px; line-height: 1.5;">Your one-time 6-digit verification code is:</p>
        <div style="text-align: center; margin: 24px 0;">
          <span style="display: inline-block; font-family: monospace; font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #1a73e8; background: #f1f3f4; padding: 14px 28px; border-radius: 8px; border: 2px dashed #4285f4;">
            ${code}
          </span>
        </div>
        <p style="color: #5f6368; font-size: 13px; line-height: 1.5;">This code will expire in 10 minutes. If you did not request this, you can safely ignore this message.</p>
        <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 24px 0;">
        <p style="color: #80868b; font-size: 12px; text-align: center; margin: 0;">&copy; 2026 ApexDrive Inc. All rights reserved.</p>
      </div>
    `
  };

  const info = await transporter.sendMail(mailOptions);
  console.log(`[Email Sent] Successfully delivered verification code to ${toEmail}. MessageId: ${info.messageId}`);
  return { success: true, messageId: info.messageId, code };
}

let customers = [
  { id: 1, firstName: 'Admin', lastName: 'User', email: 'admin@carrent.com', password: 'admin123', phone: '+1-555-0100', drivingLicense: 'DL-ADMIN-001', address: '100 Luxury Blvd, Beverly Hills, CA', role: 'ROLE_ADMIN', createdAt: new Date().toISOString() },
  { id: 2, firstName: 'Sarah', lastName: 'Connor', email: 'sarah.connor@example.com', password: 'password123', phone: '+1-555-0123', drivingLicense: 'DL-CA-987654', address: '742 Evergreen Terrace, Los Angeles, CA', role: 'ROLE_CUSTOMER', createdAt: new Date().toISOString() },
  { id: 3, firstName: 'Michael', lastName: 'Scott', email: 'michael.scott@example.com', password: 'password123', phone: '+1-555-0456', drivingLicense: 'DL-PA-123456', address: '1725 Slough Avenue, Scranton, PA', role: 'ROLE_CUSTOMER', createdAt: new Date().toISOString() }
];

let cars = [
  { id: 1, brand: 'Mercedes-Benz', model: 'S-Class S580', category: 'LUXURY', year: 2024, licensePlate: 'MERC-580-LUX', pricePerDay: 220.00, fuelType: 'Hybrid', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80', available: true, description: 'The pinnacle of luxury engineering, featuring massage seats, twin-turbo V8, and executive rear seating.' },
  { id: 2, brand: 'BMW', model: 'M4 Competition Coupe', category: 'SPORTS', year: 2023, licensePlate: 'BMW-M4-FAST', pricePerDay: 185.00, fuelType: 'Petrol', transmission: 'Automatic', seats: 4, imageUrl: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80', available: true, description: 'Track-ready performance with 503 horsepower, carbon fiber accents, and M-xDrive all-wheel drive.' },
  { id: 3, brand: 'Porsche', model: 'Taycan 4S', category: 'ELECTRIC', year: 2024, licensePlate: 'POR-TAY-ELEC', pricePerDay: 210.00, fuelType: 'Electric', transmission: 'Automatic', seats: 4, imageUrl: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=800&q=80', available: true, description: 'Pure sports car electric performance with 800V architecture and 0-60 mph in 3.8 seconds.' },
  { id: 4, brand: 'Range Rover', model: 'Sport Autobiography', category: 'SUV', year: 2024, licensePlate: 'RR-SPORT-SUV', pricePerDay: 195.00, fuelType: 'Petrol', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1606611013016-969c19ba27bb?auto=format&fit=crop&w=800&q=80', available: true, description: 'Commanding presence, peerless off-road and on-road capability, and bespoke leather cabin.' },
  { id: 5, brand: 'Tesla', model: 'Model 3 Performance', category: 'ELECTRIC', year: 2023, licensePlate: 'TESLA-M3-P', pricePerDay: 95.00, fuelType: 'Electric', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=800&q=80', available: true, description: 'Instant torque, cutting-edge autopilot tech, minimalist cabin, and 315-mile battery range.' },
  { id: 6, brand: 'Audi', model: 'RS7 Sportback', category: 'SPORTS', year: 2023, licensePlate: 'AUDI-RS7-RED', pricePerDay: 190.00, fuelType: 'Petrol', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&w=800&q=80', available: true, description: 'Aggressive widebody styling, 591-hp twin-turbo V8, Quattro AWD, and stunning sportback silhouette.' },
  { id: 7, brand: 'Mercedes-Benz', model: 'G63 AMG G-Wagon', category: 'LUXURY', year: 2024, licensePlate: 'MERC-G63-V8', pricePerDay: 290.00, fuelType: 'Petrol', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&w=800&q=80', available: true, description: 'Iconic boxy silhouette, side-exit exhausts, Burmester 3D surround sound, and handcrafted twin-turbo V8.' },
  { id: 8, brand: 'Toyota', model: 'Camry XSE Hybrid', category: 'SEDAN', year: 2024, licensePlate: 'TOY-CAM-789', pricePerDay: 55.00, fuelType: 'Hybrid', transmission: 'Automatic', seats: 5, imageUrl: 'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=800&q=80', available: true, description: 'Superb fuel efficiency (52 MPG), smooth ride, panoramic sunroof, and Toyota Safety Sense 3.0.' }
];

let rentals = [
  { id: 1, customer: customers[1], car: cars[0], startDate: '2026-11-10', endDate: '2026-11-15', totalPrice: 1100.00, status: 'CONFIRMED', pickupLocation: 'LAX Airport Terminal 3', returnLocation: 'LAX Airport Terminal 3', createdAt: new Date().toISOString() },
  { id: 2, customer: customers[2], car: cars[4], startDate: '2026-11-12', endDate: '2026-11-16', totalPrice: 380.00, status: 'PENDING', pickupLocation: 'Downtown Scranton Office', returnLocation: 'Downtown Scranton Office', createdAt: new Date().toISOString() }
];

let payments = [
  { id: 1, rental: rentals[0], amount: 1100.00, paymentDate: new Date().toISOString(), paymentMethod: 'CREDIT_CARD', paymentStatus: 'COMPLETED' }
];

const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml'
};

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch (e) { resolve({}); }
    });
  });
}

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(payload));
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*' });
    res.end();
    return;
  }

  // Handle favicon request (return 204 to clear any cached tab icon)
  if (pathname === '/favicon.ico') {
    res.writeHead(204);
    res.end();
    return;
  }

  // REST API Routes
  if (pathname === '/api/cars' && method === 'GET') {
    const { brand, category, maxPrice } = parsedUrl.query;
    let result = [...cars];
    if (category && category !== 'ALL') result = result.filter(c => c.category.toUpperCase() === category.toUpperCase());
    if (brand) result = result.filter(c => c.brand.toLowerCase().includes(brand.toLowerCase()) || c.model.toLowerCase().includes(brand.toLowerCase()));
    if (maxPrice) result = result.filter(c => Number(c.pricePerDay) <= Number(maxPrice));
    return sendJson(res, 200, result);
  }

  if (pathname.startsWith('/api/cars/') && method === 'GET') {
    const id = Number(pathname.split('/')[3]);
    const car = cars.find(c => c.id === id);
    return car ? sendJson(res, 200, car) : sendJson(res, 404, { error: 'Not found' });
  }

  if (pathname === '/api/cars' && method === 'POST') {
    const body = await readBody(req);
    const newCar = {
      id: Date.now(),
      ...body,
      pricePerDay: Number(body.pricePerDay || 150),
      available: body.available !== undefined ? body.available : true
    };
    cars.unshift(newCar);
    return sendJson(res, 201, newCar);
  }

  if (pathname.startsWith('/api/cars/') && method === 'PUT') {
    const id = Number(pathname.split('/')[3]);
    const carIndex = cars.findIndex(c => c.id === id);
    if (carIndex === -1) return sendJson(res, 404, { error: 'Car not found' });
    const body = await readBody(req);
    cars[carIndex] = { ...cars[carIndex], ...body, id };
    return sendJson(res, 200, cars[carIndex]);
  }

  if (pathname.startsWith('/api/cars/') && method === 'DELETE') {
    const id = Number(pathname.split('/')[3]);
    cars = cars.filter(c => c.id !== id);
    return sendJson(res, 200, { message: `Car ${id} deleted.` });
  }

  if (pathname === '/api/customers' && method === 'GET') return sendJson(res, 200, customers);

  if (pathname === '/api/auth/login' && method === 'POST') {
    const { email, password } = await readBody(req);
    const customer = customers.find(c => c.email.toLowerCase() === (email || '').toLowerCase());
    if (!customer || customer.password !== password) return sendJson(res, 401, { error: 'Invalid credentials' });
    const safe = { ...customer }; delete safe.password;
    return sendJson(res, 200, { message: 'Login successful', customer: safe });
  }

  if (pathname === '/api/auth/register' && method === 'POST') {
    const body = await readBody(req);
    const newCustomer = { id: Date.now(), ...body, role: 'ROLE_CUSTOMER', createdAt: new Date().toISOString() };
    customers.push(newCustomer);
    const safe = { ...newCustomer }; delete safe.password;
    return sendJson(res, 201, { message: 'Registration successful', customer: safe });
  }

  if (pathname === '/api/auth/google-send-code' && method === 'POST') {
    const { email } = await readBody(req);
    const cleanEmail = (email || '').trim().toLowerCase();
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    activeVerificationCodes.set(cleanEmail, { code, expiresAt: Date.now() + 10 * 60 * 1000 });

    let emailSent = false;
    let mailError = null;
    try {
      const result = await sendRealEmail(cleanEmail, code);
      emailSent = Boolean(result && result.success);
    } catch (err) {
      console.error('[Mail Error]', err.message);
      mailError = err.message;
    }

    return sendJson(res, 200, {
      message: emailSent ? 'Email sent to Gmail!' : 'Verification code generated',
      code,
      emailSent,
      error: mailError
    });
  }

  if (pathname === '/api/auth/google-verify' && method === 'POST') {
    const { email } = await readBody(req);
    const cleanEmail = (email || '').trim().toLowerCase();
    let customer = customers.find(c => c.email.toLowerCase() === cleanEmail);
    if (!customer) {
      const nameParts = (cleanEmail.split('@')[0] || 'Google User').replace(/[^a-zA-Z]/g, ' ').trim().split(/\s+/);
      const firstName = (nameParts[0] || 'Google').charAt(0).toUpperCase() + (nameParts[0] || 'Google').slice(1);
      const lastName = (nameParts[1] || 'User').charAt(0).toUpperCase() + (nameParts[1] || 'User').slice(1);
      customer = {
        id: Date.now(),
        firstName,
        lastName,
        email: cleanEmail,
        phone: '+216 20 000 000',
        drivingLicense: 'TN-G-' + Math.floor(100000 + Math.random() * 900000),
        address: 'Tunis, Tunisie',
        role: 'ROLE_CUSTOMER',
        createdAt: new Date().toISOString()
      };
      customers.push(customer);
    }
    const safe = { ...customer }; delete safe.password;
    return sendJson(res, 200, { message: 'Google authentication successful', customer: safe });
  }

  if (pathname === '/api/rentals' && method === 'GET') return sendJson(res, 200, rentals);

  if (pathname.startsWith('/api/rentals/customer/') && method === 'GET') {
    const customerId = Number(pathname.split('/')[4]);
    return sendJson(res, 200, rentals.filter(r => r.customer?.id === customerId));
  }

  if (pathname.startsWith('/api/rentals/') && pathname.endsWith('/cancel') && method === 'PUT') {
    const id = Number(pathname.split('/')[3]);
    const rental = rentals.find(r => r.id === id);
    if (!rental) return sendJson(res, 404, { error: 'Not found' });
    rental.status = 'CANCELLED';
    return sendJson(res, 200, rental);
  }

  if (pathname.startsWith('/api/rentals/') && method === 'PUT') {
    const id = Number(pathname.split('/')[3]);
    const rental = rentals.find(r => r.id === id);
    if (!rental) return sendJson(res, 404, { error: 'Not found' });
    const body = await readBody(req);
    Object.assign(rental, body);
    return sendJson(res, 200, rental);
  }

  if (pathname === '/api/rentals' && method === 'POST') {
    const body = await readBody(req);
    const customer = customers.find(c => c.id === body.customer?.id) || body.customer;
    const car = cars.find(c => c.id === body.car?.id) || body.car;
    const newRental = { id: Date.now(), customer, car, ...body, status: 'CONFIRMED', createdAt: new Date().toISOString() };
    rentals.push(newRental);
    return sendJson(res, 201, newRental);
  }

  // Static Assets
  let filePath = path.join(STATIC_DIR, pathname === '/' ? 'index.html' : pathname);
  if (!filePath.startsWith(STATIC_DIR)) { res.writeHead(403); res.end(); return; }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) filePath = path.join(STATIC_DIR, 'index.html');
    const ext = path.extname(filePath).toLowerCase();
    fs.readFile(filePath, (err2, content) => {
      if (err2) { res.writeHead(404); res.end('Not Found'); }
      else { res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'text/html' }); res.end(content); }
    });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Car Rental running at: http://localhost:${PORT}/`);
});

// Also listen on port 3000 if PORT is 8080 (or vice versa), so both localhost URLs work!
if (PORT != 3000) {
  const altPort = 3000;
  const altServer = http.createServer((req, res) => {
    server.emit('request', req, res);
  });
  altServer.on('error', () => {});
  altServer.listen(altPort, '0.0.0.0', () => {
    console.log(`Also listening at: http://localhost:${altPort}/`);
  });
}
