@echo off
title ApexDrive Car Rental Server
cd /d "%~dp0"
echo ====================================================================
echo   Starting ApexDrive Car Rental Website & REST API...
echo ====================================================================
node server.js
pause
